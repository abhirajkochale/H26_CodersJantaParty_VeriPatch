# Reproduce
Exact public source: https://github.com/rishrek/LinkWatch
Commit: f52f3930c8e7c33d934ccf614955a38e26984bd5

1. Start VeriPatch with Python 3.12 using the project README. The default repair engine is direct Qwen2.5-Coder 7B through local Ollama. Optional Hermes inspection uses its separate pinned runtime and veripatch-qwen3.5:4b-64k with actual 65536 context; see docs/HERMES_SETUP.md. Hermes identity, model digest, real tool messages/results, approvals and all attempts are in hermes/activity.json and verification/attempts.json.
2. Analyze this URL and confirm the recorded commit (the default UI analyzes current HEAD).
3. For exact reproduction, use `git clone`, `git checkout f52f3930c8e7c33d934ccf614955a38e26984bd5` and the fixed worker profile documented in docs/ARCHITECTURE.md.
4. Review the proposed exact-match edits and their uncertainty. Applied edit records appear in capsule.json.
5. Run the same verification profile on baseline and patched copies. Compare collection and skip counts.

Provider: LOCAL. LOCAL virtual environments are not security sandboxes.
DigitalOcean requires a configured existing Droplet. See docs/DIGITALOCEAN.md.
Exact LOCAL execution replay from the VeriPatch project root (executes trusted target code):

```bash
git clone https://github.com/rishrek/LinkWatch /private/tmp/veripatch-reproduce-baseline
git -C /private/tmp/veripatch-reproduce-baseline checkout --detach f52f3930c8e7c33d934ccf614955a38e26984bd5
app/.venv/bin/python worker/execute.py /private/tmp/veripatch-reproduce-baseline > /private/tmp/baseline.json
git clone --no-hardlinks /private/tmp/veripatch-reproduce-baseline /private/tmp/veripatch-reproduce-patched
# Unzip this capsule, then replace /absolute/path/to/capsule below:
git -C /private/tmp/veripatch-reproduce-patched apply /absolute/path/to/capsule/patches/M-final-maintenance.diff
app/.venv/bin/python worker/execute.py /private/tmp/veripatch-reproduce-patched > /private/tmp/patched.json
```

Use fresh destination directories. These direct worker invocations are LOCAL; they do not prove DigitalOcean execution. To reproduce cloud execution, configure the SSH worker and submit the recorded URL, commit, applied_edits and canonical patch hash through the fixed protocol described in docs/DIGITALOCEAN.md.

Installations are not fully locked transitively; resolved package versions and runtime are in logs. AI output may differ across repeated calls; replay the recorded diff to reproduce the applied source changes.
The capsule records observations, AI hypotheses, and executed results separately; no arbitrary model commands are executed.
