# VeriPatch · Dependency Exit Capsule

Repository: https://github.com/rishrek/LinkWatch

Commit: f52f3930c8e7c33d934ccf614955a38e26984bd5

Analysis state: completed


A completed analysis is not a successfully repaired repository.


## Coverage

{
  "inspected_files": 24,
  "python_files": 15,
  "skipped": [
    {
      "path": ".dockerignore",
      "reason": "unsupported format"
    },
    {
      "path": ".gitignore",
      "reason": "unsupported format"
    }
  ],
  "excluded_directories": [
    ".agents",
    ".aws",
    ".codex",
    ".git",
    ".pytest_cache",
    ".ruff_cache",
    ".ssh",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "venv",
    "*.egg-info"
  ],
  "limitations": [
    "Static rules cover Python AST, PEP 508 requirements and PEP 621 TOML. Other formats are inventoried as text only.",
    "Dynamic imports, arbitrary bugs, conditional constraints and distribution aliases may need manual review.",
    "No package-age inference or exhaustive bug discovery claim. Metadata unavailable is unknown."
  ]
}


## Maintenance findings

### F-7904ab7fa1 · HTTP call has no explicit timeout

Evidence: source_observed · Repair: needs_review

This call has no timeout keyword. Indirect wrappers/defaults require review.

[
  {
    "id": "E-7904ab7fa1",
    "path": "linkwatch/checker.py",
    "line": 15,
    "snippet": "session.get(url, verify=certifi.where())",
    "kind": "source_observed"
  }
]

### F-7cf6ec114e · Pydantic v1-style validator

Evidence: source_observed · Repair: fixed

Legacy validators need review if the effective environment selects Pydantic v2.

[
  {
    "id": "E-7cf6ec114e",
    "path": "linkwatch/config.py",
    "line": 14,
    "snippet": "validator(\"name\")",
    "kind": "source_observed"
  }
]

### F-ace747ac1c · Pydantic v1-style validator

Evidence: source_observed · Repair: fixed

Legacy validators need review if the effective environment selects Pydantic v2.

[
  {
    "id": "E-ace747ac1c",
    "path": "linkwatch/config.py",
    "line": 20,
    "snippet": "validator(\"url\")",
    "kind": "source_observed"
  }
]

### F-e045e6163c · URL validation checks only a prefix

Evidence: source_observed · Repair: needs_review

A scheme prefix does not establish a valid host or authority; inspect URL parsing requirements.

[
  {
    "id": "E-e045e6163c",
    "path": "linkwatch/config.py",
    "line": 22,
    "snippet": "value.startswith((\"http://\", \"https://\"))",
    "kind": "source_observed"
  }
]

### F-e38ea6df59 · Private API import

Evidence: source_observed · Repair: needs_review

Private symbols are outside the public compatibility contract; verify against the selected version.

[
  {
    "id": "E-e38ea6df59",
    "path": "linkwatch/encoding.py",
    "line": 5,
    "snippet": "from requests.utils import _parse_content_type_header",
    "kind": "source_observed"
  }
]

### F-777c4b0bdd · Dynamic codec lookup can fail

Evidence: source_observed · Repair: needs_review

Untrusted or detected encoding can cause LookupError. Inspect fallback handling and regression coverage.

[
  {
    "id": "E-777c4b0bdd",
    "path": "linkwatch/encoding.py",
    "line": 22,
    "snippet": "resp.content.decode(detect_encoding(resp), errors=\"replace\")",
    "kind": "source_observed"
  }
]

### F-1e538d2d13 · Global HTTP behavior is replaced

Evidence: source_observed · Repair: needs_review

Process-wide assignment changes Requests behavior for other callers; review scope and ordering.

[
  {
    "id": "E-1e538d2d13",
    "path": "linkwatch/http_patch.py",
    "line": 14,
    "snippet": "requests.Session.request = _request",
    "kind": "source_observed"
  }
]

### F-4af2e3a3cd · Deprecated or removed module

Evidence: source_observed · Repair: needs_review

Module has a deprecated or removed standard/distribution API; baseline execution establishes runtime impact.

[
  {
    "id": "E-4af2e3a3cd",
    "path": "linkwatch/resources.py",
    "line": 1,
    "snippet": "import pkg_resources",
    "kind": "source_observed"
  }
]

### F-3301259884 · Direct import has no matching declaration

Evidence: source_observed · Repair: needs_review

Static module-to-distribution mapping is heuristic; transitive availability is not a direct declaration.

[
  {
    "id": "E-3301259884",
    "path": "linkwatch/checker.py",
    "line": 4,
    "snippet": "certifi",
    "kind": "source_observed"
  }
]

### F-d74ef719bc · Legacy test infrastructure needs Python 3.12 validation

Evidence: source_observed · Repair: fixed

Nose uses legacy import machinery in known releases; verify the installed runner on the actual Python version.

[
  {
    "id": "E-d74ef719bc",
    "path": "requirements-dev.txt",
    "line": 1,
    "snippet": "nose==1.3.7",
    "kind": "source_observed"
  }
]

### F-dbaf11bb4c · Conflicting declarations: pydantic

Evidence: source_observed · Repair: fixed

No version can satisfy these unconditional runtime constraints: >=2, ==1.10.13

[
  {
    "id": "E-dbaf11bb4c",
    "path": "pyproject.toml",
    "line": 17,
    "snippet": "pydantic>=2",
    "kind": "source_observed"
  }
]

### F-94f7a6789f · Conflicting declarations: pydantic

Evidence: source_observed · Repair: fixed

No version can satisfy these unconditional runtime constraints: >=2, ==1.10.13

[
  {
    "id": "E-94f7a6789f",
    "path": "requirements.txt",
    "line": 5,
    "snippet": "pydantic==1.10.13",
    "kind": "source_observed"
  }
]

### X-4 · dependency-check failed

Evidence: execution_verified · Repair: fixed

Actual command exited 1

[
  {
    "id": "E-X-4",
    "kind": "execution_verified",
    "command": [
      "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/execution-95ad59835d54429bae487387bcbf68ba/target-env/bin/python",
      "-m",
      "pip",
      "check"
    ],
    "cwd": "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/baseline-repo",
    "provider": "LOCAL",
    "path": null,
    "line": null,
    "snippet": "linkwatch 0.3.1 has requirement pydantic>=2, but you have pydantic 1.10.13.\n"
  }
]

### X-7 · nose-compatibility failed

Evidence: execution_verified · Repair: fixed

Actual command exited 1

[
  {
    "id": "E-X-7",
    "kind": "execution_verified",
    "command": [
      "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/execution-95ad59835d54429bae487387bcbf68ba/target-env/bin/python",
      "-c",
      "import importlib.util; spec=importlib.util.find_spec('nose'); print('nose absent: no installed legacy runner' if spec is None else 'nose installed: importing for compatibility'); exec('import nose; print(nose.__version__)') if spec else None"
    ],
    "cwd": "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/baseline-repo",
    "provider": "LOCAL",
    "path": null,
    "line": null,
    "snippet": "Traceback (most recent call last):\n  File \"<string>\", line 1, in <module>\n  File \"<string>\", line 1, in <module>\n  File \"/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/execution-95ad59835d54429bae487387bcbf68ba/target-env/lib/python3.12/site-packages/nose/__init__.py\", line 1, in <module>\n    from nose.core import collector, main, run, run_exit, runmodule\n  File \"/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/execution-95ad59835d54429bae487387bcbf68ba/target-env/lib/python3.12/site-packages/nose/core.py\", line 12, in <module>\n    from nose.loader import defaultTestLoader\n  File \"/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/execution-95ad59835d54429bae487387bcbf68ba/target-env/lib/python3.12/site-packages/nose/loader.py\", line 21, in <module>\n    from nose.importer import Importer, add_path, remove_path\n  File \"/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/execution-95ad59835d54429bae487387bcbf68ba/target-env/lib/python3.12/site-packages/nose/importer.py\", line 12, in <module>\n    from imp import find_module, load_module, acquire_lock, release_lock\nModuleNotFoundError: No module named 'imp'\n"
  }
]

### X-9 · tests failed

Evidence: execution_verified · Repair: fixed

Actual command exited 1

[
  {
    "id": "E-X-9",
    "kind": "execution_verified",
    "command": [
      "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/execution-95ad59835d54429bae487387bcbf68ba/target-env/bin/python",
      "-m",
      "pytest",
      "-q",
      "-ra",
      "-p",
      "vp_probe"
    ],
    "cwd": "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/baseline-repo",
    "provider": "LOCAL",
    "path": null,
    "line": null,
    "snippet": "-env/lib/python3.12/site-packages/click/core.py:1415: in invoke\n    return ctx.invoke(self.callback, **ctx.params)\n../execution-95ad59835d54429bae487387bcbf68ba/target-env/lib/python3.12/site-packages/click/core.py:910: in invoke\n    return callback(*args, **kwargs)\nlinkwatch/cli.py:56: in report\n    from .report import render_report\nlinkwatch/report.py:3: in <module>\n    from jinja2 import Environment, FileSystemLoader, select_autoescape\n../execution-95ad59835d54429bae487387bcbf68ba/target-env/lib/python3.12/site-packages/jinja2/__init__.py:12: in <module>\n    from .environment import Environment\n../execution-95ad59835d54429bae487387bcbf68ba/target-env/lib/python3.12/site-packages/jinja2/environment.py:25: in <module>\n    from .defaults import BLOCK_END_STRING\n../execution-95ad59835d54429bae487387bcbf68ba/target-env/lib/python3.12/site-packages/jinja2/defaults.py:3: in <module>\n    from .filters import FILTERS as DEFAULT_FILTERS  # noqa: F401\n_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ \n\n    # -*- coding: utf-8 -*-\n    \"\"\"Built-in template filters used with the ``|`` operator.\"\"\"\n    import math\n    import random\n    import re\n    import warnings\n    from collections import namedtuple\n    from itertools import chain\n    from itertools import groupby\n    \n    from markupsafe import escape\n    from markupsafe import Markup\n>   from markupsafe import soft_unicode\nE   ImportError: cannot import name 'soft_unicode' from 'markupsafe' (/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/execution-95ad59835d54429bae487387bcbf68ba/target-env/lib/python3.12/site-packages/markupsafe/__init__.py)\n\n../execution-95ad59835d54429bae487387bcbf68ba/target-env/lib/python3.12/site-packages/jinja2/filters.py:13: ImportError\n=============================== warnings summary ===============================\nlinkwatch/resources.py:1\n  /Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/8f5c766cc3e34bfeb359784bfe42d70b/baseline-repo/linkwatch/resources.py:1: DeprecationWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html\n    import pkg_resources\n\n-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html\n=========================== short test summary info ============================\nFAILED tests/test_report.py::test_report_renders_all_sites - ImportError: can...\n1 failed, 9 passed, 1 warning in 6.55s\n"
  }
]

### X-10 · declared-test-workflow failed

Evidence: execution_verified · Repair: fixed

Fresh profile v2 command exited 2

[
  {
    "id": "E-X-10",
    "kind": "execution_verified",
    "path": null,
    "line": null,
    "command": [
      "make",
      "test-nose",
      "PYTHON=/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/execution-8585640900704d7b8cb4d0106367f6ff/target-env/bin/python"
    ],
    "cwd": "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/baseline-repo",
    "provider": "LOCAL",
    "snippet": "Traceback (most recent call last):\n  File \"/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/execution-8585640900704d7b8cb4d0106367f6ff/target-env/bin/nosetests\", line 5, in <module>\n    from nose import run_exit\n  File \"/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/execution-8585640900704d7b8cb4d0106367f6ff/target-env/lib/python3.12/site-packages/nose/__init__.py\", line 1, in <module>\n    from nose.core import collector, main, run, run_exit, runmodule\n  File \"/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/execution-8585640900704d7b8cb4d0106367f6ff/target-env/lib/python3.12/site-packages/nose/core.py\", line 12, in <module>\n    from nose.loader import defaultTestLoader\n  File \"/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/execution-8585640900704d7b8cb4d0106367f6ff/target-env/lib/python3.12/site-packages/nose/loader.py\", line 21, in <module>\n    from nose.importer import Importer, add_path, remove_path\n  File \"/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/execution-8585640900704d7b8cb4d0106367f6ff/target-env/lib/python3.12/site-packages/nose/importer.py\", line 12, in <module>\n    from imp import find_module, load_module, acquire_lock, release_lock\nModuleNotFoundError: No module named 'imp'\nmake: *** [test-nose] Error 1\n\nnosetests tests/\n"
  }
]

### X-11 · report-tests failed

Evidence: execution_verified · Repair: fixed

Fresh profile v2 command exited 1

[
  {
    "id": "E-X-11",
    "kind": "execution_verified",
    "path": null,
    "line": null,
    "command": [
      "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/execution-8585640900704d7b8cb4d0106367f6ff/target-env/bin/python",
      "-m",
      "pytest",
      "-q",
      "tests/test_report.py"
    ],
    "cwd": "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/baseline-repo",
    "provider": "LOCAL",
    "snippet": "6ff/target-env/lib/python3.12/site-packages/click/core.py:1415: in invoke\n    return ctx.invoke(self.callback, **ctx.params)\n../execution-8585640900704d7b8cb4d0106367f6ff/target-env/lib/python3.12/site-packages/click/core.py:910: in invoke\n    return callback(*args, **kwargs)\nlinkwatch/cli.py:56: in report\n    from .report import render_report\nlinkwatch/report.py:3: in <module>\n    from jinja2 import Environment, FileSystemLoader, select_autoescape\n../execution-8585640900704d7b8cb4d0106367f6ff/target-env/lib/python3.12/site-packages/jinja2/__init__.py:12: in <module>\n    from .environment import Environment\n../execution-8585640900704d7b8cb4d0106367f6ff/target-env/lib/python3.12/site-packages/jinja2/environment.py:25: in <module>\n    from .defaults import BLOCK_END_STRING\n../execution-8585640900704d7b8cb4d0106367f6ff/target-env/lib/python3.12/site-packages/jinja2/defaults.py:3: in <module>\n    from .filters import FILTERS as DEFAULT_FILTERS  # noqa: F401\n_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ \n\n    # -*- coding: utf-8 -*-\n    \"\"\"Built-in template filters used with the ``|`` operator.\"\"\"\n    import math\n    import random\n    import re\n    import warnings\n    from collections import namedtuple\n    from itertools import chain\n    from itertools import groupby\n    \n    from markupsafe import escape\n    from markupsafe import Markup\n>   from markupsafe import soft_unicode\nE   ImportError: cannot import name 'soft_unicode' from 'markupsafe' (/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/execution-8585640900704d7b8cb4d0106367f6ff/target-env/lib/python3.12/site-packages/markupsafe/__init__.py)\n\n../execution-8585640900704d7b8cb4d0106367f6ff/target-env/lib/python3.12/site-packages/jinja2/filters.py:13: ImportError\n=============================== warnings summary ===============================\nlinkwatch/resources.py:1\n  /Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/baseline-repo/linkwatch/resources.py:1: DeprecationWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html\n    import pkg_resources\n\n-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html\n=========================== short test summary info ============================\nFAILED tests/test_report.py::test_report_renders_all_sites - ImportError: can...\n1 failed, 1 warning in 0.07s\n"
  }
]

### M-d61abac4fc · Legacy Nose invocation cannot run on Python 3.12.

Evidence: source_observed · Repair: fixed

Legacy Nose invocation cannot run on Python 3.12.

[
  {
    "id": "E-M-d61abac4fc",
    "path": "Makefile",
    "line": 14,
    "snippet": "nosetests tests/",
    "kind": "source_observed",
    "observer": "maintainer"
  }
]

### M-a1383eaedc · Target documentation must describe the migrated compatibility alias.

Evidence: source_observed · Repair: fixed

Target documentation must describe the migrated compatibility alias.

[
  {
    "id": "E-M-a1383eaedc",
    "path": "README.md",
    "line": 214,
    "snippet": "| `make test-nose` | Run the suite with nose |",
    "kind": "source_observed",
    "observer": "maintainer"
  }
]


## Dependency inventory

[
  {
    "name": "appdirs",
    "declarations": [
      {
        "name": "appdirs",
        "constraint": "==1.4.4",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "appdirs==1.4.4"
      },
      {
        "name": "appdirs",
        "constraint": "==1.4.4",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "appdirs==1.4.4"
      }
    ],
    "usage": [
      {
        "module": "appdirs",
        "path": "linkwatch/cache.py",
        "line": 4
      }
    ],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [],
    "disposition": "no_static_finding"
  },
  {
    "name": "chardet",
    "declarations": [
      {
        "name": "chardet",
        "constraint": "==5.2.0",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "chardet==5.2.0"
      },
      {
        "name": "chardet",
        "constraint": "==5.2.0",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "chardet==5.2.0"
      }
    ],
    "usage": [
      {
        "module": "chardet",
        "path": "linkwatch/encoding.py",
        "line": 4
      }
    ],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [],
    "disposition": "no_static_finding"
  },
  {
    "name": "click",
    "declarations": [
      {
        "name": "click",
        "constraint": ">=7",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "click>=7"
      },
      {
        "name": "click",
        "constraint": ">=7",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "click>=7"
      }
    ],
    "usage": [
      {
        "module": "click",
        "path": "linkwatch/cli.py",
        "line": 1
      },
      {
        "module": "click.testing",
        "path": "tests/test_report.py",
        "line": 1
      }
    ],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [],
    "disposition": "no_static_finding"
  },
  {
    "name": "idna",
    "declarations": [
      {
        "name": "idna",
        "constraint": "==2.7",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "idna==2.7"
      },
      {
        "name": "idna",
        "constraint": "==2.7",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "idna==2.7"
      }
    ],
    "usage": [],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [],
    "disposition": "no_static_finding"
  },
  {
    "name": "jinja2",
    "declarations": [
      {
        "name": "jinja2",
        "constraint": "==2.11.3",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "Jinja2==2.11.3"
      },
      {
        "name": "jinja2",
        "constraint": "==2.11.3",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "Jinja2==2.11.3"
      }
    ],
    "usage": [
      {
        "module": "jinja2",
        "path": "linkwatch/report.py",
        "line": 3
      }
    ],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [],
    "disposition": "no_static_finding"
  },
  {
    "name": "nose",
    "declarations": [
      {
        "name": "nose",
        "constraint": "==1.3.7",
        "marker": null,
        "url": null,
        "path": "requirements-dev.txt",
        "group": "development",
        "raw": "nose==1.3.7"
      }
    ],
    "usage": [],
    "constraint_status": "unknown",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [
      "F-d74ef719bc"
    ],
    "disposition": "needs_review"
  },
  {
    "name": "pydantic",
    "declarations": [
      {
        "name": "pydantic",
        "constraint": ">=2",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "pydantic>=2"
      },
      {
        "name": "pydantic",
        "constraint": "==1.10.13",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "pydantic==1.10.13"
      }
    ],
    "usage": [
      {
        "module": "pydantic",
        "path": "linkwatch/config.py",
        "line": 4
      }
    ],
    "constraint_status": "conflicting",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [
      "F-7cf6ec114e",
      "F-ace747ac1c",
      "F-dbaf11bb4c",
      "F-94f7a6789f"
    ],
    "disposition": "needs_review"
  },
  {
    "name": "pytest",
    "declarations": [
      {
        "name": "pytest",
        "constraint": "",
        "marker": null,
        "url": null,
        "path": "requirements-dev.txt",
        "group": "development",
        "raw": "pytest"
      }
    ],
    "usage": [
      {
        "module": "pytest",
        "path": "tests/conftest.py",
        "line": 6
      }
    ],
    "constraint_status": "unknown",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [],
    "disposition": "no_static_finding"
  },
  {
    "name": "python-dateutil",
    "declarations": [
      {
        "name": "python-dateutil",
        "constraint": "",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "python-dateutil"
      },
      {
        "name": "python-dateutil",
        "constraint": "",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "python-dateutil"
      }
    ],
    "usage": [
      {
        "module": "dateutil",
        "path": "linkwatch/dates.py",
        "line": 1
      }
    ],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [],
    "disposition": "no_static_finding"
  },
  {
    "name": "requests",
    "declarations": [
      {
        "name": "requests",
        "constraint": "==2.31.0",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "requests==2.31.0"
      },
      {
        "name": "requests",
        "constraint": "==2.31.0",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "requests==2.31.0"
      }
    ],
    "usage": [
      {
        "module": "requests",
        "path": "linkwatch/checker.py",
        "line": 5
      },
      {
        "module": "requests",
        "path": "linkwatch/checker.py",
        "line": 6
      },
      {
        "module": "requests.utils",
        "path": "linkwatch/encoding.py",
        "line": 5
      },
      {
        "module": "requests",
        "path": "linkwatch/http_patch.py",
        "line": 1
      }
    ],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [
      "F-7904ab7fa1",
      "F-e38ea6df59",
      "F-1e538d2d13"
    ],
    "disposition": "needs_review"
  },
  {
    "name": "rich",
    "declarations": [
      {
        "name": "rich",
        "constraint": "",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "rich"
      },
      {
        "name": "rich",
        "constraint": "",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "rich"
      }
    ],
    "usage": [
      {
        "module": "rich.console",
        "path": "linkwatch/cli.py",
        "line": 2
      },
      {
        "module": "rich.live",
        "path": "linkwatch/cli.py",
        "line": 3
      },
      {
        "module": "rich.table",
        "path": "linkwatch/cli.py",
        "line": 4
      }
    ],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [],
    "disposition": "no_static_finding"
  },
  {
    "name": "setuptools",
    "declarations": [
      {
        "name": "setuptools",
        "constraint": "==75.8.0",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "setuptools==75.8.0"
      },
      {
        "name": "setuptools",
        "constraint": ">=61",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "build",
        "raw": "setuptools>=61"
      },
      {
        "name": "setuptools",
        "constraint": "==75.8.0",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "setuptools==75.8.0"
      }
    ],
    "usage": [
      {
        "module": "pkg_resources",
        "path": "linkwatch/resources.py",
        "line": 1
      }
    ],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [
      "F-4af2e3a3cd"
    ],
    "disposition": "needs_review"
  },
  {
    "name": "six",
    "declarations": [
      {
        "name": "six",
        "constraint": "",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "six"
      },
      {
        "name": "six",
        "constraint": "",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "six"
      }
    ],
    "usage": [],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [],
    "disposition": "no_static_finding"
  },
  {
    "name": "toml",
    "declarations": [
      {
        "name": "toml",
        "constraint": "==0.10.2",
        "marker": null,
        "url": null,
        "path": "pyproject.toml",
        "group": "runtime",
        "raw": "toml==0.10.2"
      },
      {
        "name": "toml",
        "constraint": "==0.10.2",
        "marker": null,
        "url": null,
        "path": "requirements.txt",
        "group": "runtime",
        "raw": "toml==0.10.2"
      }
    ],
    "usage": [
      {
        "module": "toml",
        "path": "linkwatch/config.py",
        "line": 3
      }
    ],
    "constraint_status": "compatible",
    "metadata_status": "unknown: remote package metadata not queried",
    "finding_ids": [],
    "disposition": "no_static_finding"
  }
]


## AI recommendations (hypotheses)

[
  {
    "at": "2026-10-15T10:34:18.094138+00:00",
    "model": "qwen2.5-coder:7b",
    "status": "completed",
    "role": "diagnostic_review",
    "provenance_note": "Fresh bounded direct-Qwen diagnostic review. Report/Pydantic advice rejected by maintainer; this is not an autonomous repair proposal.",
    "response": {
      "summary": "{\n  \"report_diagnosis\": \"The report import failure is due to compatibility issues with the `nose` testing framework and the `markupsafe` library in Python 3.12. The `nose` framework is not compatible with Python 3.12, and the `markupsafe` library has deprecated the `soft_unicode` function, which is used in the `nose` framework.\",\n  \"nose_migration\": \"To migrate from `nose` to a supported test-runner, we can use `pytest`, which is a widely used and supported testing framework for Python. We can also use `pytest` to run the existing tests in the `tests` directory.\",\n  \"pydantic_compatibility\": \"The `pydantic` library has deprecated the `pydantic>=2` requirement in the `pyproject.toml` file. We need to update the `pydantic` requirement to `pydantic==1.10.13` to maintain compatibility with the existing codebase.\",\n  \"recommended_constraints\": \"To ensure compatibility with Python 3.12 and the existing codebase, we can update the `requirements.txt` and `pyproject.toml` files as follows:\",\n  \"uncertainty\": \"The exact guarded edits will be derived by the maintainer.\"\n}\nMaintainer assessment: Pytest migration suggestion supported; report attribution to Nose and Pydantic downgrade advice rejected as inconsistent with actual traceback and official migration guidance.",
      "unresolved_issue_ids": []
    }
  }
]


## Verification

{
  "checks_passed": true,
  "reasons": [],
  "before_counts": {
    "collected": 10,
    "passed": 9,
    "failed": 1,
    "skipped": 0,
    "errors": 0
  },
  "after_counts": {
    "collected": 10,
    "passed": 10,
    "failed": 0,
    "skipped": 0,
    "errors": 0
  },
  "scope": {
    "before": [
      "create-env",
      "tooling",
      "install-requirements",
      "install-project",
      "dependency-check",
      "resolved-packages",
      "compile",
      "nose-compatibility",
      "collect-tests",
      "tests",
      "declared-test-workflow",
      "report-tests"
    ],
    "after": [
      "create-env",
      "tooling",
      "install-requirements",
      "install-project",
      "dependency-check",
      "resolved-packages",
      "compile",
      "nose-compatibility",
      "collect-tests",
      "tests",
      "declared-test-workflow",
      "report-tests"
    ]
  },
  "claim": "Passing checks support only the executed profile; individual issues still require reinspection/review."
}


## Errors and unresolved concerns

[]


## Executed baseline

Provider: LOCAL

Counts: `{"collected": 10, "passed": 9, "failed": 1, "skipped": 0, "errors": 0}`

Profile: `python312-requirements-project-nodeps-pytest-v2`

| Command | Exit | Seconds | Timeout |

|---|---:|---:|---|

| create-env | 0 | 1.28 | False |

| tooling | 0 | 0.67 | False |

| install-requirements | 0 | 3.48 | False |

| install-project | 0 | 1.27 | False |

| dependency-check | 1 | 0.19 | False |

| resolved-packages | 0 | 0.13 | False |

| compile | 0 | 0.04 | False |

| nose-compatibility | 1 | 0.13 | False |

| collect-tests | 0 | 0.51 | False |

| tests | 1 | 6.85 | False |

| declared-test-workflow | 2 | 0.5 | False |

| report-tests | 1 | 0.29 | False |


## Executed verification

Provider: LOCAL

Counts: `{"collected": 10, "passed": 10, "failed": 0, "skipped": 0, "errors": 0}`

Profile: `python312-requirements-project-nodeps-pytest-v2`

| Command | Exit | Seconds | Timeout |

|---|---:|---:|---|

| create-env | 0 | 1.2 | False |

| tooling | 0 | 1.05 | False |

| install-requirements | 0 | 5.93 | False |

| install-project | 0 | 1.48 | False |

| dependency-check | 0 | 0.18 | False |

| resolved-packages | 0 | 0.13 | False |

| compile | 0 | 0.04 | False |

| nose-compatibility | 0 | 0.02 | False |

| collect-tests | 0 | 0.66 | False |

| tests | 0 | 6.83 | False |

| declared-test-workflow | 0 | 6.83 | False |

| report-tests | 0 | 1.06 | False |


## Authorship and retained evidence

Repair engine: MAINTAINER_ASSISTED_WITH_QWEN_REVIEW

Inspection engine: HERMES

Hermes records retain their original timestamps. Historical Qwen responses are not new inference.

[
  {
    "id": "M-final-maintenance",
    "authored_by": "Maintainer-assisted repair; historical direct-Qwen Pydantic edits; fresh Qwen diagnostic review recorded separately",
    "status": "checks_passed",
    "provenance": null
  }
]


## Retained Hermes activity (original timestamps)

{
  "type": "identity",
  "hermes": {
    "base_version": "unknown",
    "derived_version": "git.db44c46",
    "distance": null,
    "commit": "db44c46208f1b421b4ecb7e56bf9d68b0423906f",
    "branch": "main",
    "source": "git",
    "dirty": false,
    "commit_date": 1792051073,
    "distribution": null
  },
  "license": "MIT",
  "model": "veripatch-qwen3.5:4b-64k"
}


## Remaining limitations

[
  "All original 10 tests, actual pytest replacement invocation and explicit report test pass in comparable v2 profiles. This is not exhaustive bug discovery.",
  "Seven unchanged source observations need review with specific next actions; URL authority validation is outside scored maintenance scope.",
  "The actual fresh Qwen diagnostic response contained incorrect report/Pydantic advice; it is retained with maintainer assessment, not attributed as a correct autonomous repair. Approved final edits are maintainer-assisted, preserving the historical direct-Qwen Pydantic repair.",
  "Hermes autonomous patch generation is disabled; actual historical and fresh inspection tool events are distinguished by phase/timestamp.",
  "LOCAL executes trusted target code in disposable venvs, not a security sandbox. DigitalOcean optional and unverified.",
  "Dependencies are not transitively locked; exact resolved package versions, commands, source hashes and replay patch are retained."
]


## Additional behavior validation

{
  "baseline": {
    "name": "pydantic-contract",
    "argv": [
      "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/execution-8585640900704d7b8cb4d0106367f6ff/target-env/bin/python",
      "-c",
      "from pydantic import ValidationError\nfrom linkwatch.config import Site, Settings\nassert Site(name=\" A \",url=\" https://example.org \").name == \"A\"\nassert Site(name=\" A \",url=\" https://example.org \").url == \"https://example.org\"\nfor construct in (lambda: Site(name=\"\",url=\"https://example.org\"),lambda: Site(name=\"A\",url=\"ftp://example.org\"),lambda: Settings(unexpected=True)):\n    try: construct()\n    except ValidationError: pass\n    else: raise AssertionError(\"validation behavior was lost\")\nprint(\"whitespace stripping, nonempty name, HTTP scheme and extra-field validation verified\")\n"
    ],
    "cwd": "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/baseline-repo",
    "exit_code": 0,
    "stdout": "whitespace stripping, nonempty name, HTTP scheme and extra-field validation verified\n",
    "stderr": ""
  },
  "verification": {
    "name": "pydantic-contract",
    "argv": [
      "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/execution-70592374f2a646b097f984804b12653d/target-env/bin/python",
      "-c",
      "from pydantic import ValidationError\nfrom linkwatch.config import Site, Settings\nassert Site(name=\" A \",url=\" https://example.org \").name == \"A\"\nassert Site(name=\" A \",url=\" https://example.org \").url == \"https://example.org\"\nfor construct in (lambda: Site(name=\"\",url=\"https://example.org\"),lambda: Site(name=\"A\",url=\"ftp://example.org\"),lambda: Settings(unexpected=True)):\n    try: construct()\n    except ValidationError: pass\n    else: raise AssertionError(\"validation behavior was lost\")\nprint(\"whitespace stripping, nonempty name, HTTP scheme and extra-field validation verified\")\n"
    ],
    "cwd": "/Users/nishi/Downloads/Developer/H26_CodersJantaParty_VeriPatch/.veripatch/6ff0dd70641c4f0abc837206baba5ff4/patched-81b97d39",
    "exit_code": 0,
    "stdout": "whitespace stripping, nonempty name, HTTP scheme and extra-field validation verified\n",
    "stderr": ""
  }
}